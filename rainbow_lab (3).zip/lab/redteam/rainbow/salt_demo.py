#!/usr/bin/env python3
"""Show why a precomputed unsalted lookup cannot be reused across random salts."""

try:
    import bcrypt
    from argon2 import PasswordHasher, Type
except ImportError as exc:
    raise SystemExit(
        f"Missing Python dependency: {exc}. Install in your lab venv: "
        ".venv/bin/python -m pip install bcrypt argon2-cffi"
    ) from exc

PASSWORD = "student123"  # Synthetic training credential, never a real password.


def show_bcrypt() -> None:
    raw = PASSWORD.encode("utf-8")
    first = bcrypt.hashpw(raw, bcrypt.gensalt(rounds=12))
    second = bcrypt.hashpw(raw, bcrypt.gensalt(rounds=12))
    print("=== bcrypt: random salt ===")
    print("Cost: 12")
    print("Hash 1:", first.decode("ascii"))
    print("Hash 2:", second.decode("ascii"))
    print("Same password, different hashes:", first != second)
    print("Verify correct password against Hash 1:", bcrypt.checkpw(raw, first))
    print("Direct reuse of Hash 1 as Hash 2:", first == second)


def show_argon2id() -> None:
    hasher = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=4, type=Type.ID)
    first = hasher.hash(PASSWORD)
    second = hasher.hash(PASSWORD)
    print("\n=== Argon2id: random salt ===")
    print("Cost: memory=65536 KiB, time=3, parallelism=4")
    print("Hash 1:", first)
    print("Hash 2:", second)
    print("Same password, different hashes:", first != second)
    print("Verify correct password against Hash 1:", hasher.verify(first, PASSWORD))
    print("Direct reuse of Hash 1 as Hash 2:", first == second)


if __name__ == "__main__":
    show_bcrypt()
    show_argon2id()
