#!/usr/bin/env bash
# Run from any working directory. Results are generated on the user's Kali VM.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
cd "$ROOT"
PYTHON="python3"
if [[ -x .venv/bin/python ]]; then
  PYTHON=".venv/bin/python"
fi
OUT="lab/redteam/rainbow"
"$PYTHON" "$OUT/md5_rainbow.py" build | tee "$OUT/md5_build_result.txt"
"$PYTHON" "$OUT/md5_rainbow.py" lookup | tee "$OUT/md5_result.txt"
"$PYTHON" "$OUT/salt_demo.py" | tee "$OUT/salt_result.txt"
printf '\nSaved results under %s/\n' "$OUT"
