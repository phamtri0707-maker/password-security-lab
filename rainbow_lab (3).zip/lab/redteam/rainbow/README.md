# Rainbow table demonstration (Red Team)

Controlled **offline synthetic-data lab** using `lab/redteam/wordlists/wordlist-100.txt`, `md5/hash.txt` and the training password `student123`.

## Running on Kali

From the repository root (on `feature/redteam`):

```bash
.venv/bin/python -m pip install bcrypt argon2-cffi
bash lab/redteam/rainbow/run_all.sh
```

You may run the MD5 phases independently:

```bash
python3 lab/redteam/rainbow/md5_rainbow.py build
python3 lab/redteam/rainbow/md5_rainbow.py lookup
```

`build` writes the persistent `md5_table.csv` (start and endpoint of each chain). `lookup` **reads the saved table** and the target in `../md5/hash.txt`. There is no need to rebuild the table before later lookups, provided the **same wordlist, order and code** are used. `run_all.sh` rebuilds it for reproducibility.

## Outputs

- `md5_table.csv`: saved chain start/end pairs; this is a reduced-storage rainbow-chain table, **not** a full hash-to-password lookup dictionary.
- `md5_build_result.txt`: preparation cost and table size.
- `md5_result.txt`: lookup result and measured lookup duration.
- `salt_result.txt`: comparison of two separately salted bcrypt and Argon2id hashes for the **same synthetic password**.

Only commit these lab artifacts if they contain synthetic credentials. Never push real passwords, real breached datasets, environment secrets or private TLS keys.

## Scientific limitations

- A rainbow table relies on precomputation with hash/reduction chains. The reduction function maps hashes to candidate passwords; it **does not reverse MD5**.
- This intentionally small demo starts a chain from **each wordlist entry**, ensuring that an MD5 target generated from a candidate in that list can be found. This artificially improves coverage and is **not** a claim of efficient storage or speed.
- Rainbow lookups can have chain collisions and false alarms. We reconstruct and verify the candidate before reporting success.
- `salt_demo.py` demonstrates that new random salts produce different hashes. It **does not prove bcrypt/Argon2id cannot be cracked**, or that precomputation is mathematically impossible for a fixed known salt.
- For just 100 candidates, timing differences will be small and not comparable to previous John or Argon2id benchmarks. Separate preparation cost from lookup cost. The chosen MD5 hash is deliberately unsalted; MD5 is not suitable for storing passwords.
