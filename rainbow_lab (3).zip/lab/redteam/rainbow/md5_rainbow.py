#!/usr/bin/env python3
"""Educational MD5 rainbow table with column-dependent reduction functions.

Uses synthetic lab data only. build writes a chain start/end table; lookup
uses that saved table and independently verifies any recovered candidate.
"""

import csv
import hashlib
import hmac
import sys
import time
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
REDTEAM = HERE.parent
WORDLIST_FILE = REDTEAM / "wordlists" / "wordlist-100.txt"
TARGET_FILE = REDTEAM / "md5" / "hash.txt"
TABLE_FILE = HERE / "md5_table.csv"
CHAIN_LENGTH = 12


def md5(text: str) -> str:
    return hashlib.md5(text.encode("utf-8")).hexdigest()


def reduce_hash(digest: str, column: int, candidates: list[str]) -> str:
    """Map 128-bit MD5 output to a wordlist candidate (NOT inverse hashing)."""
    index = (int(digest, 16) + (column + 1) * 1315423911) % len(candidates)
    return candidates[index]


def make_endpoint(start: str, candidates: list[str]) -> str:
    password = start
    for column in range(CHAIN_LENGTH):
        password = reduce_hash(md5(password), column, candidates)
    return password


def load_candidates() -> list[str]:
    if not WORDLIST_FILE.is_file():
        raise SystemExit(f"Wordlist not found: {WORDLIST_FILE}")
    candidates = list(dict.fromkeys(
        line.strip() for line in WORDLIST_FILE.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ))
    if not candidates:
        raise SystemExit("Wordlist is empty")
    return candidates


def build(candidates: list[str]) -> None:
    started = time.perf_counter()
    with TABLE_FILE.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(("start", "end"))
        # Using every wordlist candidate as a head ensures reproducible lab coverage.
        # This choice is made for DEMONSTRATION, not optimal storage efficiency.
        for start in candidates:
            writer.writerow((start, make_endpoint(start, candidates)))
    print("=== MD5 rainbow table: BUILD ===")
    print(f"Wordlist size: {len(candidates)}")
    print(f"Chains saved: {len(candidates)}")
    print(f"Chain length: {CHAIN_LENGTH}")
    print(f"Table path: {TABLE_FILE}")
    print(f"Build time: {time.perf_counter() - started:.6f} s")


def lookup(candidates: list[str]) -> None:
    if not TABLE_FILE.is_file():
        raise SystemExit("No saved table. Run 'build' first.")
    if not TARGET_FILE.is_file():
        raise SystemExit(f"Target hash not found: {TARGET_FILE}")
    target = TARGET_FILE.read_text(encoding="utf-8").strip().lower()
    if len(target) != 32 or any(c not in "0123456789abcdef" for c in target):
        raise SystemExit("Target is not a valid 32-character MD5 hex digest")

    endings: dict[str, list[str]] = defaultdict(list)
    with TABLE_FILE.open(newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            endings[row["end"]].append(row["start"])

    started = time.perf_counter()
    checked_chains = set()
    for position in range(CHAIN_LENGTH - 1, -1, -1):
        # If target is H(P_position), follow reductions to the saved endpoint.
        digest = target
        endpoint = ""
        for column in range(position, CHAIN_LENGTH):
            endpoint = reduce_hash(digest, column, candidates)
            digest = md5(endpoint)

        for start in endings.get(endpoint, []):
            if start in checked_chains:
                continue
            checked_chains.add(start)
            # A matching endpoint alone is not proof: reconstruct and verify.
            password = start
            for column in range(CHAIN_LENGTH):
                digest = md5(password)
                if hmac.compare_digest(digest, target):
                    print("=== MD5 rainbow table: LOOKUP ===")
                    print(f"Target hash: {target}")
                    print(f"Password found: {password}")
                    print("Crack successful: True")
                    print(f"Lookup time: {time.perf_counter() - started:.6f} s")
                    return
                password = reduce_hash(digest, column, candidates)

    print("=== MD5 rainbow table: LOOKUP ===")
    print(f"Target hash: {target}")
    print("Password not found in saved table")
    print("Crack successful: False")
    print(f"Lookup time: {time.perf_counter() - started:.6f} s")


def main() -> None:
    if len(sys.argv) != 2 or sys.argv[1] not in {"build", "lookup"}:
        raise SystemExit("Usage: python3 md5_rainbow.py build|lookup")
    candidates = load_candidates()
    if sys.argv[1] == "build":
        build(candidates)
    else:
        lookup(candidates)


if __name__ == "__main__":
    main()
